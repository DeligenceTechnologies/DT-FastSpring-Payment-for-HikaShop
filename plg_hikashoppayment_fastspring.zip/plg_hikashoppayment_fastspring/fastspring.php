<?php
/**
 * @package	This plugin enables you to setup your FastSpring payment gateway with Hikashop
 * @version	2.6.4
 * @author	www.deligence.com
 * @copyright	(C) 2010-2017 Deligence Technologies Pvt Ltd.. All rights reserved.
 * @license	GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
	defined('_JEXEC') or die('Restricted access');
	$baseUrl = getcwd();
	if(strpos($baseUrl, 'administrator'))
		$baseUrl = substr($baseUrl,0, -13);
	else
		$baseUrl = $baseUrl.'\\';
	$srcfile=$baseUrl.'media\com_hikashop\images\payment\fs\FastSpring.png';
	$dstfile=$baseUrl.'media\com_hikashop\images\payment\FastSpring.png';
	if(!file_exists($dstfile)){
		copy($srcfile, $dstfile);
}
class plgHikashoppaymentFastSpring extends hikashopPaymentPlugin
{
	var $accepted_currencies = array( "EUR", "USD" ); 
	var $multiple = true; // Multiple plugin configurations. It should usually be set to true
	var $name = 'fastspring'; //Payment plugin name (the name of the PHP file)

	var $pluginConfig = array(
		'title' => array("Title",'input'), //User's title on the payment platform
		'company_id' => array("Company ID",'input'), //User's company ID on the payment platform
		'environment' => array('Test Mode', 'boolean','0'), //Write some things on the debug file
		'invalid_status' => array('INVALID_STATUS', 'orderstatus'), //Invalid status for order in case of problem during the payment process
		'verified_status' => array('VERIFIED_STATUS', 'orderstatus') //Valid status for order if the payment has been done well
	);

	//This function is called at the end of the checkout. That's the function which should display your payment gateway redirection form with the data from HikaShop
	function onAfterOrderConfirm(&$order,&$methods,$method_id)
	{
		parent::onAfterOrderConfirm($order,$methods,$method_id); // This is a mandatory line in order to initialize the attributes of the payment method

		//Here we can do some checks on the options of the payment method and make sure that every required parameter is set and otherwise display an error message to the user
		if (empty($this->payment_params->title)) //The plugin can only work if those parameters are configured on the website's backend
		{
			$this->app->enqueueMessage('You have to configure an title for the FastSpring plugin payment first : check your plugin\'s parameters, on your website backend','error');
			//Enqueued messages will appear to the user, as Joomla's error messages
			return false;
		}
		elseif (empty($this->payment_params->company_id))
		{
			$this->app->enqueueMessage('You have to configure a company ID for the FastSpring plugin payment first : check your plugin\'s parameters, on your website backend','error');
			return false;
		}
		else
		{
			//Here, all the required parameters are valid, so we can proceed to the payment platform


			$amout = round($order->cart->full_total->prices[0]->price_value_with_tax,2)*100;

			$this->payment_params->payment_url = "http://sites.fastspring.com/".$this->payment_params->company_id."/api/order";

			//This array contains all the required parameters by the payment plateform
			//Not all the payment platforms will need all these parameters and they will probably have a different name.
			//You need to look at the payment gateway integration guide provided by the payment gateway in order to know what is needed here
			$vars = array(
				'operation'=>'create',
				'destination'=>'contents',
				'mode'=>$this->payment_params->environment,
				'referrer' => $order->order_id,
				'contact_email' => $order->cart->customer->email, 
				'contact_fname' => $order->cart->shipping_address->address_firstname,
				'contact_lname' => $order->cart->shipping_address->address_lastname,
				'contact_phone' => $order->cart->shipping_address->address_telephone
			);

			//adding cart details
			$i=1;
			foreach ($order->cart->products as $item) {
				$key='product_'.$i.'_path';
			    $vars[$key] = '/'.$item->order_product_name;
				$key_q='product_'.$i.'_quantity';
				$vars[$key_q] = $item->order_product_quantity;
				$i++;
		    }
		    
			$vars['HASH'] = $this->fastspring_signature($this->payment_params->company_id,$vars);
			//Hash generated to certify the values integrity
			//This hash is generated according to the plateform requirements
			$this->vars = $vars;
			
			//Ending the checkout, ready to be redirect to the plateform payment final form
			//The showPage function will call the fastspring_end.php file which will display the redirection form containing all the parameters for the payment platform
			return $this->showPage('end'); 
		}
	}


	//To set the specific configuration (back end) default values (see $pluginConfig array)
	function getPaymentDefaultValues(&$element)
	{
		$element->payment_name='FastSpring';
		$element->payment_description='You can pay by credit card using this payment method';
		$element->payment_images='FastSpring';
		$element->payment_params->address_type="billing";
		$element->payment_params->notification=1;
		$element->payment_params->invalid_status='cancelled';
		$element->payment_params->verified_status='confirmed';
	}


	//After submiting the plateform payment form, this is where the website will receive the response information from the payment gateway servers and then validate or not the order
	function onPaymentNotification(&$statuses)
	{
		//We first create a filtered array from the parameters received
		$vars = array();
		$filter = JFilterInput::getInstance();
		foreach($_REQUEST as $key => $value)
		{
			$key = $filter->clean($key);
			$value = JRequest::getString($key);
			$vars[$key]=$value;
		}

		//TWe load the parameters of the plugin in $this->payment_params and the order data based on the order_id coming from the payment platform
		$order_id = (int)@$vars['ORDERID'];
		$dbOrder = $this->getOrder($order_id);
		$this->loadPaymentParams($dbOrder);
		if(empty($this->payment_params))
			return false;
		$this->loadOrderData($dbOrder);

		//Configure the "succes URL" and the "fail URL" to redirect the user if necessary (not necessary for our fastspring platform
		$return_url = HIKASHOP_LIVE.'index.php?option=com_hikashop&ctrl=checkout&task=after_end&order_id='.$order_id.$this->url_itemid;
		$cancel_url = HIKASHOP_LIVE.'index.php?option=com_hikashop&ctrl=order&task=cancel_order&order_id='.$order_id.$this->url_itemid;

		//Recalculate the hash to check if the information received are identical to those sent by the payment platform
		$hash = $this->fastspring_signature($this->payment_params->company_id,$vars,false,true);
		if($this->payment_params->debug) //Debug mode activated or not
		{
			//Here we display debug information which will be catched by HikaShop and stored in the payment log file available in the configuration's Files section.
			echo print_r($vars,true)."\n\n\n";
			echo print_r($dbOrder,true)."\n\n\n";
			echo print_r($hash,true)."\n\n\n";
		}

		//Confirm or not the Order, depending of the information received
		if (strcasecmp($hash,$vars['HASH'])!=0) //Different hash between what we calculate and the hash ent by the payment platform so we do not do anything as we consider that the notification doesn't come from the payment platform.
		{
			//Here we display debug information which will be catched by HikaShop and stored in the payment log file available in the configuration's Files section.
			if($this->payment_params->debug)
				echo 'Hash error '.$vars['HASH'].' - '.$hash."\n\n\n";
			return false;
		}
		elseif($vars['EXECCODE']!='0000') //Return code different from success so we set the "invalid" status to the order
		{
			//Here we display debug information which will be catched by HikaShop and stored in the payment log file available in the configuration's Files section.
			if($this->payment_params->debug)
				echo 'payment '.$vars['MESSAGE']."\n\n\n";
			
			//This function modifies the order with the id $order_id, to attribute it the status invalid_status.
			$this->modifyOrder($order_id, $this->payment_params->invalid_status, true, true); 
			
			return false;
		}
		else //If everything's OK, order is validated -> success
		{
			$this->modifyOrder($order_id, $this->payment_params->verified_status, true, true);
			
			//$this->app->redirect($return_url);
			return true;
		}
	}


	//To generate the Hash, according to the payment plateform requirement
	function fastspring_signature($company_id, $parameters, $debug=false, $decode=false)
	{
		ksort($parameters); //Ordering the parameters in alphabetic order because the fastspring platform requires us to do that for the hash calculation
		$clear_string = $company_id;
		//All the keys wondered / sent by the payment plateform
		$expectedKey = array (
			'TITLE',
			'TRANSACTIONID',
			'CLIENTIDENT',
			'CLIENTEMAIL',
			'ORDERID',
			'VERSION',
			'LANGUAGE',
			'CURRENCY',
			'EXTRADATA',
			'CARDCODE',
			'CARDCOUNTRY',
			'EXECCODE',
			'MESSAGE',
			'DESCRIPTOR',
			'ALIAS',
			'3DSECURE',
			'AMOUNT',
		);


		//Here we construct the hash string according to the payment gateway's requirements
		//String before hashing : passwordTITLE=TotopasswordVERSION=2password ...
		foreach ($parameters as $key => $value)
		{
			if ($decode)
			{
				if (in_array($key,$expectedKey))
					$clear_string .= $key . '=' . $value . $company_id;
			}
			else
				$clear_string .= $key . '=' . $value . $company_id;
		}


		if (PHP_VERSION_ID < 50102) //As the payment gateway fastspring wants us to use the hash function which is not available below PHP 5.1.2, we have this check here
		{
			$this->app->enqueueMessage('The FastSpring payment plugin requires at least the PHP 5.1.2 version to work, but it seems that it is not available on your server. Please contact your web hosting to set it up.','error');
			return false;
		}
		else
		{
			if ($debug)
				return $clear_string;
			else
				return hash('sha256', $clear_string); //String hashed with a sha256 method, as required by the fastspring platform
		}
	}

}
